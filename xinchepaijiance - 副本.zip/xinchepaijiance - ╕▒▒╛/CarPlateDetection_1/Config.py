#coding:utf-8

# 图片及视频检测结果保存路径
save_path = 'save_data'

# 使用的模型路径
# model_path = 'models/best.pt'
model_path = 'C:/Users/13939/Desktop/CarPlateDetection_1/CarPlateDetection_1/models/best.pt'

names = {0:'License'}

CH_names = ['车牌']