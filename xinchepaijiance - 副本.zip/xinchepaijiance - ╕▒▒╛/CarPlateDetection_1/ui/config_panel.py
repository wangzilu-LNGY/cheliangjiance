from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton

class ConfigPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # OCR Model Path
        self.ocr_model_label = QLabel("OCR Model Path")
        self.ocr_model_input = QLineEdit()
        layout.addWidget(self.ocr_model_label)
        layout.addWidget(self.ocr_model_input)

        # YOLO Weights Path
        self.yolo_weight_label = QLabel("YOLO Weights Path")
        self.yolo_weight_input = QLineEdit()
        layout.addWidget(self.yolo_weight_label)
        layout.addWidget(self.yolo_weight_input)

        # Save Button
        self.save_btn = QPushButton("Save Configuration")
        layout.addWidget(self.save_btn)

        self.setLayout(layout)
        self.save_btn.clicked.connect(self.save_configuration)

    def save_configuration(self):
        ocr_model_path = self.ocr_model_input.text()
        yolo_weight_path = self.yolo_weight_input.text()
        self.save_config(ocr_model_path, yolo_weight_path)

    def save_config(self, ocr_model_path, yolo_weight_path):
        # Implement the logic to save the configuration
        print(f"OCR Model Path: {ocr_model_path}")
        print(f"YOLO Weights Path: {yolo_weight_path}")
        # You can add code here to save the configuration to a file or a database