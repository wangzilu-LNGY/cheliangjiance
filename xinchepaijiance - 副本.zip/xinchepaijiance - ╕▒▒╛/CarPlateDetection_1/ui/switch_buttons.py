from PyQt5.QtWidgets import QWidget, QHBoxLayout, QPushButton
from PyQt5.QtCore import pyqtSignal

class SwitchButtons(QWidget):
    # Define signals for button clicks
    camera_clicked = pyqtSignal()
    image_clicked = pyqtSignal()
    video_clicked = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()

    def initUI(self):
        # Create the layout and buttons
        layout = QHBoxLayout()
        self.camera_btn = QPushButton("Camera")
        self.image_btn = QPushButton("Image")
        self.video_btn = QPushButton("Video")

        # Add the buttons to the layout
        layout.addWidget(self.camera_btn)
        layout.addWidget(self.image_btn)
        layout.addWidget(self.video_btn)

        # Set the layout for the widget
        self.setLayout(layout)

        # Connect button clicks to signals
        self.camera_btn.clicked.connect(self.emit_camera_clicked)
        self.image_btn.clicked.connect(self.emit_image_clicked)
        self.video_btn.clicked.connect(self.emit_video_clicked)

    def emit_camera_clicked(self):
        self.camera_clicked.emit()

    def emit_image_clicked(self):
        self.image_clicked.emit()

    def emit_video_clicked(self):
        self.video_clicked.emit()