from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QFileDialog
from PyQt5.QtGui import QFont
from ultralytics import YOLO
from paddleocr import PaddleOCR
import cv2

class DetectionDisplay(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()
        self.detector = None
        self.ocr = None
        self.yolo = None
        self.cap = None

    def initUI(self):
        layout = QVBoxLayout()
        self.detection_label = QLabel("Detection Results")
        self.detection_label.setFont(QFont("Arial", 16))
        layout.addWidget(self.detection_label)
        self.setLayout(layout)

    def set_detection_mode(self, mode):
        if mode == "camera":
            self.start_camera_detection()
        elif mode == "image":
            self.start_image_detection()
        elif mode == "video":
            self.start_video_detection()

    def start_camera_detection(self):
        try:
            ocr_model_path = self.parent().config_panel.ocr_model_input.text()
            yolo_weight_path = self.parent().config_panel.yolo_weight_input.text()
            self.load_models(ocr_model_path, yolo_weight_path)
            self.detect_plates_from_camera()
        except Exception as e:
            print(f"Error starting camera detection: {e}")
            self.display_detection_result("Error occurred during detection.")

    def detect_plates_from_camera(self):
        ID = 0
        while ID < 10:
            self.cap = cv2.VideoCapture(ID)
            ret, frame = self.cap.read()
            if ret == False:
                ID += 1
            else:
                print('Camera ID:', ID)
                break

        while self.cap.isOpened():
            success, frame = self.cap.read()
            if success:
                plate_info = self.detector.detect_plates(frame)
                self.display_detection_result(plate_info)

                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            else:
                break

        self.cap.release()
        cv2.destroyAllWindows()

    def start_image_detection(self):
        # Implement the logic to start image detection
        pass

    def start_video_detection(self):
        try:
            ocr_model_path = self.parent().config_panel.ocr_model_input.text()
            yolo_weight_path = self.parent().config_panel.yolo_weight_input.text()
            self.load_models(ocr_model_path, yolo_weight_path)
            self.detect_plates_from_video()
        except Exception as e:
            print(f"Error starting video detection: {e}")
            self.display_detection_result("Error occurred during detection.")

    def detect_plates_from_video(self):
        video_path = "TestFiles/1.mp4"
        self.cap = cv2.VideoCapture(video_path)

        while self.cap.isOpened():
            success, frame = self.cap.read()
            if success:
                plate_info = self.detector.detect_plates(frame)
                self.display_detection_result(plate_info)

                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            else:
                break

        self.cap.release()
        cv2.destroyAllWindows()

    def display_detection_result(self, plate_info):
        result_text = "\n".join([plate["plate"] for plate in plate_info])
        self.detection_label.setText(result_text)

        self.save_btn = QPushButton("Save Result")
        self.save_btn.clicked.connect(self.save_detection_result)
        self.layout().addWidget(self.save_btn)

    def save_detection_result(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Detection Result", "", "Text Files (*.txt)")
        if file_path:
            with open(file_path, "w") as f:
                f.write(self.detection_label.text())

    def load_models(self, ocr_model_path, yolo_weight_path):
        # Load OCR model
        cls_model_dir = ocr_model_path + '/cls'
        rec_model_dir = ocr_model_path + '/rec'
        self.ocr = PaddleOCR(use_angle_cls=False, lang="ch", det=False, cls_model_dir=cls_model_dir, rec_model_dir=rec_model_dir)

        # Load YOLO model
        self.yolo = YOLO(yolo_weight_path)
        self.detector = CarPlateDetector(self.yolo, self.ocr)

class CarPlateDetector:
    def __init__(self, yolo_model, ocr_model):
        self.yolo = yolo_model
        self.ocr = ocr_model
        self.font = cv2.FONT_HERSHEY_SIMPLEX

    def detect_plates(self, frame):
        results = self.yolo(frame)[0]
        plate_info = []

        for result in results.boxes.xyxy:
            x1, y1, x2, y2 = [int(v) for v in result]
            plate_img = frame[y1:y2, x1:x2]
            license_num, conf = self.get_license_result(plate_img)
            plate_info.append({"plate": license_num, "confidence": conf})

        return plate_info

    def get_license_result(self, image):
        result = self.ocr.ocr(image, cls=True)[0]
        if result:
            license_name, conf = result[0][1]
            if '·' in license_name:
                license_name = license_name.replace('·', '')
            return license_name, conf
        else:
            return None, None