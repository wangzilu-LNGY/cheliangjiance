from PyQt5.QtWidgets import QMainWindow, QVBoxLayout, QWidget
from .switch_buttons import SwitchButtons
from .detection_display import DetectionDisplay
from .config_panel import ConfigPanel

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Car Plate Detection")
        self.setGeometry(100, 100, 1280, 720)

        # Create the main layout
        main_layout = QVBoxLayout()

        # Create the child widgets
        self.switch_buttons = SwitchButtons(self)
        self.detection_display = DetectionDisplay(self)
        self.config_panel = ConfigPanel(self)

        # Add the child widgets to the main layout
        main_layout.addWidget(self.switch_buttons)
        main_layout.addWidget(self.detection_display)
        main_layout.addWidget(self.config_panel)

        # Set the main widget and layout
        main_widget = QWidget()
        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)

        # Connect the signals and slots
        self._connect_signals_and_slots()

    def _connect_signals_and_slots(self):
        self.switch_buttons.camera_clicked.connect(self._switch_to_camera)
        self.switch_buttons.image_clicked.connect(self._switch_to_image)
        self.switch_buttons.video_clicked.connect(self._switch_to_video)
        self.config_panel.save_btn.clicked.connect(self._save_configuration)

    def _switch_to_camera(self):
        self.detection_display.set_detection_mode("camera")

    def _switch_to_image(self):
        self.detection_display.set_detection_mode("image")

    def _switch_to_video(self):
        self.detection_display.set_detection_mode("video")

    def _save_configuration(self):
        ocr_model_path = self.config_panel.ocr_model_input.text()
        yolo_weight_path = self.config_panel.yolo_weight_input.text()
        self.detection_display.load_models(ocr_model_path, yolo_weight_path)