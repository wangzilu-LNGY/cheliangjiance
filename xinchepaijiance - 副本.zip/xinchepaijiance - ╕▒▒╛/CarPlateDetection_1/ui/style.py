QPushButton {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    font-size: 16px;
}

QPushButton:hover {
    background-color: #45a049;
}

QLabel {
    font-size: 18px;
    font-weight: bold;
}

QLineEdit {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
}